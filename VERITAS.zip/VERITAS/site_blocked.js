document.addEventListener("DOMContentLoaded", function() {
  const backBtn = document.getElementById("goBackBtn");
  const proceedBtn = document.getElementById("proceedBtn");
  const openExtensionsBtn = document.getElementById("openExtensionsBtn");
  const instructions = document.getElementById("instructions");

  // set extension-hosted badge image if available
  try {
    const badge = document.querySelector('img[data-ext-src]');
    if (badge && chrome && chrome.runtime && chrome.runtime.getURL) {
      const rel = badge.getAttribute('data-ext-src');
      if (rel) badge.src = chrome.runtime.getURL(rel);
    }
  } catch (e) {
    // ignore
  }

  if (backBtn) backBtn.addEventListener("click", goBack);
  if (proceedBtn) proceedBtn.addEventListener("click", showDisableInstructions);
  if (openExtensionsBtn) openExtensionsBtn.addEventListener("click", openExtensionsPage);
});

function getOriginalUrl() {
  const params = new URLSearchParams(window.location.search);
  return params.get("url") || "";
}

function goBack() {
  if (document.referrer) {
    window.location.href = document.referrer;
  } else {
    window.close();
  }
}

function showDisableInstructions() {
  // Show the instructions and the "Open Extensions Page" button
  const instructions = document.getElementById("instructions");
  const openExtensionsBtn = document.getElementById("openExtensionsBtn");
  if (instructions) instructions.style.display = "block";
  if (openExtensionsBtn) openExtensionsBtn.style.display = "inline-block";
}

function openExtensionsPage() {
  if (chrome && chrome.tabs) {
    chrome.tabs.create({ url: "chrome://extensions/" });
  } else {
    alert("Please open chrome://extensions/ manually.");
  }
}
